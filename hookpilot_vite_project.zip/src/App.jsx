import React, { useEffect, useMemo, useState } from "react";

const SAMPLE_PRESETS = [
  {
    label: "Shorts Hook",
    value: "This cat waited outside the hospital for 3 days… then the door finally opened.",
  },
  {
    label: "Title + Hook",
    value: "He ignored this puppy for one week… until the puppy did THIS.",
  },
  {
    label: "Weak Example",
    value: "Today I want to talk about my video and share some thoughts with you.",
  },
];

const curiosityWords = ["wait", "suddenly", "only", "before", "after", "until", "never", "why", "how", "secret", "hidden", "wrong", "finally", "unexpected", "nobody"];
const emotionWords = ["cry", "love", "hurt", "saved", "lost", "fear", "alone", "family", "heart", "pain", "happy", "shock", "relief", "hero"];
const urgencyWords = ["now", "today", "right", "instant", "fast", "quick", "before", "last", "first", "suddenly"];
const stakeWords = ["save", "risk", "lose", "win", "survive", "danger", "chance", "mystery", "secret", "proof", "truth", "attack", "escape"];

const storageKeys = {
  user: "hookpilot_user_v1",
  history: "hookpilot_history_v1",
};

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function makeSummary(score) {
  if (score >= 80) return "Good hook. It is short, clear, and scroll-stopping.";
  if (score >= 60) return "Decent base. It needs more curiosity or stronger tension.";
  return "Weak start. It explains too much and does not create a reason to keep watching.";
}

function generateRewrites(text, score, hasCuriosity, hasEmotion, hasStake, hasNumber) {
  const base = text.replace(/\s+/g, " ").trim();
  const shortBase = base.length > 80 ? base.slice(0, 77).trim() + "…" : base;
  const lines = [];

  if (score >= 80) {
    lines.push(`Keep the core idea. Make the payoff slightly later: “${shortBase}”`);
    lines.push("Try a sharper version: “You will not believe what happened after this.”");
    lines.push(`Add one more tension word: “${shortBase}”`);
  } else if (score >= 60) {
    lines.push(hasCuriosity ? `Make it punchier: “${shortBase}”` : "Add curiosity: “Nobody expected this to happen next…”");
    lines.push(hasEmotion ? "Keep the emotion, but cut filler." : "Add emotion: “This looked harmless, but it changed everything.”");
    lines.push(hasStake ? "Push the consequence harder." : "Show what was about to be lost.");
  } else {
    lines.push("“Something was wrong… and nobody noticed it at first.”");
    lines.push("“This looked normal, until the last second.”");
    lines.push("“One small moment changed the whole video.”");
  }

  if (hasNumber || score < 70) lines.push(`“${shortBase.split(" ").slice(0, 10).join(" ")}”`);
  return lines.slice(0, 4);
}

function generateThumbnailFix(text, score) {
  const lower = text.toLowerCase();
  const hasFace = /cat|dog|child|man|woman|boy|girl|owner|baby|animal/.test(lower);
  const hasTextPrompt = /why|how|wait|suddenly|secret|shock|danger|save/.test(lower);
  const notes = [];

  if (score >= 80) {
    notes.push("Thumbnail can stay simple.");
    notes.push("Use 2 to 4 words only.");
    notes.push("Show one clear emotion.");
  } else {
    notes.push("Use one face or one main subject.");
    notes.push("Keep text short and bold.");
    notes.push("Make the result obvious in one glance.");
  }

  if (!hasFace) notes.push("Add a human or animal emotion point.");
  if (!hasTextPrompt) notes.push("Try text like: 'What happened?', 'Too late', 'Wait for it'.");

  return notes.slice(0, 4);
}

function generateRetentionTips(score, hasEmotion, hasStake) {
  const tips = [];
  if (score >= 80) {
    tips.push("Keep the first line fast.");
    tips.push("Show the payoff just a little later.");
    tips.push("Use one strong visual every 2–3 seconds.");
  } else {
    tips.push("Cut the intro.");
    tips.push("Start from the problem, not the explanation.");
    tips.push("Add tension before the full story.");
  }
  if (!hasEmotion) tips.push("Add a feeling: fear, love, shock, relief, or loss.");
  if (!hasStake) tips.push("Show what can be lost or gained.");
  return tips.slice(0, 4);
}

function analyzeText(text) {
  const clean = text.trim();
  const words = clean ? clean.split(/\s+/).filter(Boolean) : [];
  const lower = clean.toLowerCase();

  const hasCuriosity = curiosityWords.some((w) => lower.includes(w));
  const hasEmotion = emotionWords.some((w) => lower.includes(w));
  const hasUrgency = urgencyWords.some((w) => lower.includes(w));
  const hasStake = stakeWords.some((w) => lower.includes(w));
  const hasNumber = /\d/.test(clean);
  const hasQuestion = /\?/.test(clean);
  const hasEllipse = /\.{3}|…/.test(clean);

  let score = 38;
  if (words.length >= 5 && words.length <= 18) score += 10;
  if (words.length > 18) score -= 8;
  if (words.length < 3) score -= 10;
  if (hasCuriosity) score += 12;
  if (hasEmotion) score += 10;
  if (hasUrgency) score += 6;
  if (hasStake) score += 10;
  if (hasNumber) score += 7;
  if (hasQuestion) score += 3;
  if (hasEllipse) score += 4;
  if (/\b(I want to talk|today I|this is about|in this video)\b/i.test(clean)) score -= 14;
  if (/\bhello|hi everyone|welcome back\b/i.test(lower)) score -= 8;
  score = clamp(score, 5, 98);

  const issues = [];
  if (words.length < 5) issues.push("Too short. Add a clear situation.");
  if (words.length > 18) issues.push("Too long. Cut the setup.");
  if (!hasCuriosity) issues.push("No curiosity word. Add tension or surprise.");
  if (!hasEmotion) issues.push("No emotion. Make the viewer feel something.");
  if (!hasStake) issues.push("No stakes. Show what is at risk.");
  if (!hasNumber && !hasQuestion) issues.push("No pattern break. Add a number or question.");
  if (/\bI want to talk|today I|in this video\b/i.test(clean)) issues.push("Sounds generic. Start with the moment, not the explanation.");

  const strengths = [];
  if (hasCuriosity) strengths.push("Curiosity is present.");
  if (hasEmotion) strengths.push("Emotion is present.");
  if (hasStake) strengths.push("There is a real consequence.");
  if (hasNumber) strengths.push("A number makes it easier to stop the scroll.");
  if (hasQuestion) strengths.push("A question creates instant open loop.");
  if (strengths.length === 0) strengths.push("Clear enough to understand fast.");

  const style = score >= 80 ? "Strong" : score >= 60 ? "Okay" : score >= 40 ? "Weak" : "Very weak";

  return {
    score,
    style,
    summary: makeSummary(score),
    strengths,
    issues,
    rewrites: generateRewrites(clean, score, hasCuriosity, hasEmotion, hasStake, hasNumber),
    thumbnail: generateThumbnailFix(clean, score),
    retention: generateRetentionTips(score, hasEmotion, hasStake),
  };
}

function downloadTextFile(filename, content, mime = "text/plain") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function App() {
  const [input, setInput] = useState(SAMPLE_PRESETS[0].value);
  const [userName, setUserName] = useState("");
  const [loginInput, setLoginInput] = useState("");
  const [history, setHistory] = useState([]);
  const [copied, setCopied] = useState("");
  const analysis = useMemo(() => analyzeText(input), [input]);
  const progressColor =
    analysis.score >= 80
      ? "emerald"
      : analysis.score >= 60
        ? "cyan"
        : analysis.score >= 40
          ? "amber"
          : "rose";

  useEffect(() => {
    try {
      const savedUser = localStorage.getItem(storageKeys.user);
      const savedHistory = localStorage.getItem(storageKeys.history);
      if (savedUser) setUserName(savedUser);
      if (savedHistory) setHistory(JSON.parse(savedHistory));
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(storageKeys.history, JSON.stringify(history));
    } catch {
      // ignore
    }
  }, [history]);

  const isLoggedIn = Boolean(userName);

  const handleCopy = async (label, text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(label);
      window.setTimeout(() => setCopied(""), 1400);
    } catch {
      setCopied("Failed");
    }
  };

  const reportText = useMemo(() => {
    return [
      `Hook score: ${analysis.score}/100`,
      `Style: ${analysis.style}`,
      `Summary: ${analysis.summary}`,
      ``,
      `Strengths:`,
      ...analysis.strengths.map((item) => `- ${item}`),
      ``,
      `Issues:`,
      ...(analysis.issues.length ? analysis.issues.map((item) => `- ${item}`) : ["- No major issue found."]),
      ``,
      `Better rewrites:`,
      ...analysis.rewrites.map((item) => `- ${item}`),
      ``,
      `Thumbnail fixes:`,
      ...analysis.thumbnail.map((item) => `- ${item}`),
      ``,
      `Retention tips:`,
      ...analysis.retention.map((item) => `- ${item}`),
    ].join("\n");
  }, [analysis]);

  const saveCurrent = () => {
    if (!isLoggedIn) return;
    const entry = {
      id: crypto.randomUUID?.() || String(Date.now()),
      userName,
      input,
      score: analysis.score,
      style: analysis.style,
      summary: analysis.summary,
      createdAt: new Date().toISOString(),
    };
    setHistory((prev) => [entry, ...prev].slice(0, 50));
  };

  const login = () => {
    const clean = loginInput.trim();
    if (!clean) return;
    setUserName(clean);
    setLoginInput("");
    try {
      localStorage.setItem(storageKeys.user, clean);
    } catch {
      // ignore
    }
  };

  const logout = () => {
    setUserName("");
    setHistory([]);
    try {
      localStorage.removeItem(storageKeys.user);
      localStorage.removeItem(storageKeys.history);
    } catch {
      // ignore
    }
  };

  const exportHistory = (format) => {
    const rows = history.map((item) => ({
      createdAt: item.createdAt,
      score: item.score,
      style: item.style,
      summary: item.summary,
      input: item.input,
    }));

    if (format === "csv") {
      const header = ["createdAt", "score", "style", "summary", "input"];
      const csv = [
        header.join(","),
        ...rows.map((row) =>
          header
            .map((key) => `"${String(row[key] ?? "").replaceAll('"', '""')}"`)
            .join(","),
        ),
      ].join("\n");
      downloadTextFile("hookpilot-history.csv", csv, "text/csv");
      return;
    }

    downloadTextFile("hookpilot-history.json", JSON.stringify(rows, null, 2), "application/json");
  };

  const saveAndCopy = () => {
    if (isLoggedIn) saveCurrent();
    handleCopy("report", reportText);
  };

  return (
    <div className="app-shell">
      <div className="bg-glow" />
      <main className="container">
        <section className="hero">
          <div className="hero-copy">
            <span className="pill">Premium creator analytics</span>
            <h1>
              Why Your Video Won&apos;t Go Viral
              <span>Analyzer</span>
            </h1>
            <p>
              Paste your hook, title, or script. Get a fast score, weak points, better rewrites, thumbnail fixes, and retention tips in simple words.
            </p>

            <div className="hero-actions">
              <button className="btn btn-light" onClick={() => handleCopy("headline", "Analyze your hook now")}>Copy headline</button>
              <button className="btn btn-ghost" onClick={() => document.getElementById("editor")?.scrollIntoView({ behavior: "smooth" })}>See the analyzer</button>
            </div>

            <div className="feature-grid">
              <FeatureCard title="Fast score" text="Instant hook score from 1–100" />
              <FeatureCard title="Simple words" text="No confusing jargon, just clear fixes" />
              <FeatureCard title="Creator focused" text="Built for Shorts, Reels, and YouTube" />
            </div>
          </div>

          <aside className="preview-card">
            <div className="card-head">
              <h3>Live result preview</h3>
              <p>This shows the style of the app output.</p>
            </div>

            <div className="score-box">
              <div>
                <small>Hook score</small>
                <strong>{analysis.score}/100</strong>
              </div>
              <div className="score-badge">{analysis.style}</div>
            </div>

            <div className="bar-wrap">
              <div className={`bar bar-${progressColor}`} style={{ width: `${analysis.score}%` }} />
            </div>

            <div className="mini-grid">
              <MiniTile title="Best part" text={analysis.strengths[0]} />
              <MiniTile title="Biggest issue" text={analysis.issues[0] || "Looks okay at first glance."} />
            </div>
          </aside>
        </section>

        <section className="control-grid" id="editor">
          <article className="panel">
            <div className="panel-head">
              <div>
                <h2>Paste your text</h2>
                <p>Hook, title, intro, or full short script.</p>
              </div>
              <div className="preset-row">
                {SAMPLE_PRESETS.map((preset) => (
                  <button key={preset.label} className="chip" onClick={() => setInput(preset.value)}>
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Paste your hook or script here..."
            />

            <div className="action-row">
              <button className="btn btn-primary" onClick={() => {}}>
                Analyze instantly
              </button>
              <button className="btn btn-ghost" onClick={() => handleCopy("input", input)}>
                Copy input
              </button>
              <button className="btn btn-ghost" onClick={() => handleCopy("rewrites", analysis.rewrites.join("\n"))}>
                Copy rewrites
              </button>
            </div>

            <div className="help-text">Short, sharp, and honest.</div>
          </article>

          <article className="panel">
            <div className="panel-head">
              <div>
                <h2>Login</h2>
                <p>Local login for saving history in this browser.</p>
              </div>
              <span className={`status ${isLoggedIn ? "ok" : "guest"}`}>
                {isLoggedIn ? "Signed in" : "Guest"}
              </span>
            </div>

            {!isLoggedIn ? (
              <>
                <input
                  value={loginInput}
                  onChange={(e) => setLoginInput(e.target.value)}
                  placeholder="Enter your name or email"
                />
                <button className="btn btn-light full" onClick={login}>
                  Login and save history
                </button>
                <div className="help-text">
                  Without login, nothing is stored. With login, your history stays in this browser.
                </div>
              </>
            ) : (
              <>
                <div className="user-box">
                  Logged in as <strong>{userName}</strong>
                </div>
                <div className="button-grid">
                  <button className="btn btn-light" onClick={saveCurrent}>Save current result</button>
                  <button className="btn btn-ghost" onClick={logout}>Logout</button>
                  <button className="btn btn-ghost" onClick={() => exportHistory("json")}>Export JSON</button>
                  <button className="btn btn-ghost" onClick={() => exportHistory("csv")}>Export CSV</button>
                </div>
              </>
            )}
          </article>
        </section>

        <section className="analytics-grid">
          <article className="panel">
            <div className="panel-head">
              <div>
                <h2>Fast analytics</h2>
                <p>Quick read for fast decisions.</p>
              </div>
            </div>

            <div className="metrics-grid">
              <MetricCard title="Hook score" value={`${analysis.score}/100`} helper="How strong the first line is" />
              <MetricCard title="Swipe risk" value={analysis.score >= 80 ? "Low" : analysis.score >= 60 ? "Medium" : "High"} helper="Chance people skip" />
              <MetricCard title="Clarity" value={analysis.score >= 75 ? "Strong" : "Okay"} helper="Simple to understand fast" />
              <MetricCard title="Emotion" value={analysis.score >= 70 ? "Good" : "Needs work"} helper="Feeling, shock, or tension" />
            </div>

            <div className="snapshot">
              <div className="snapshot-top">
                <span>Performance snapshot</span>
                <span>{analysis.summary}</span>
              </div>
              <BarChartSimple values={[86, 73, 81, 90, 78]} labels={["Hook", "Curiosity", "Emotion", "Clarity", "Retention"]} />
            </div>
          </article>

          <article className="panel">
            <div className="panel-head">
              <div>
                <h2>Saved history</h2>
                <p>Your last saved checks.</p>
              </div>
              <div className="button-row">
                <button className="btn btn-ghost" onClick={() => handleCopy("history", history.map((item, idx) => `${idx + 1}. ${item.score}/100 — ${item.summary}\n${item.input}`).join("\n\n") || "No saved history yet.")}>
                  Copy all
                </button>
                <button className="btn btn-ghost" onClick={() => exportHistory("json")}>Export</button>
              </div>
            </div>

            {isLoggedIn ? (
              history.length ? (
                <div className="history-list">
                  {history.slice(0, 5).map((item) => (
                    <div key={item.id} className="history-item">
                      <div className="history-top">
                        <strong>{item.score}/100 • {item.style}</strong>
                        <small>{new Date(item.createdAt).toLocaleString()}</small>
                      </div>
                      <p>{item.summary}</p>
                      <div className="history-input">{item.input}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="empty-box">No saved history yet. Login, then click “Save current result”.</div>
              )
            ) : (
              <div className="empty-box">Login first to save and export history.</div>
            )}
          </article>
        </section>

        <section className="triple-grid">
          <CopyPanel
            title="What works"
            items={analysis.strengths}
            onCopy={() => handleCopy("works", analysis.strengths.join("\n"))}
          />
          <CopyPanel
            title="What fails"
            items={analysis.issues.length ? analysis.issues : ["No major issue found."]}
            onCopy={() => handleCopy("fails", analysis.issues.join("\n"))}
          />
          <CopyPanel
            title="Premium outputs"
            items={["4 better hook rewrites", "Thumbnail text ideas", "Retention fix tips", "Shareable report card"]}
            onCopy={saveAndCopy}
          />
        </section>

        <section className="double-grid">
          <article className="panel">
            <div className="panel-head">
              <div>
                <h2>Better rewrites</h2>
                <p>These are written to stop the scroll.</p>
              </div>
              <button className="btn btn-ghost" onClick={() => handleCopy("rewrites", analysis.rewrites.join("\n"))}>
                Copy rewrites
              </button>
            </div>

            <div className="stack">
              {analysis.rewrites.map((item, idx) => (
                <div key={item} className="list-card">
                  <span>{idx + 1}</span>
                  <p>{item}</p>
                </div>
              ))}
            </div>
          </article>

          <article className="panel">
            <div className="panel-head">
              <div>
                <h2>Thumbnail and retention fixes</h2>
                <p>Simple fixes you can actually use.</p>
              </div>
              <button className="btn btn-ghost" onClick={() => handleCopy("fixes", [...analysis.thumbnail, ...analysis.retention].join("\n"))}>
                Copy fixes
              </button>
            </div>

            <div className="fix-grid">
              <div className="sub-panel">
                <h3>Thumbnail</h3>
                <div className="stack">
                  {analysis.thumbnail.map((item) => (
                    <div key={item} className="mini-list">{item}</div>
                  ))}
                </div>
              </div>

              <div className="sub-panel">
                <h3>Retention</h3>
                <div className="stack">
                  {analysis.retention.map((item) => (
                    <div key={item} className="mini-list">{item}</div>
                  ))}
                </div>
              </div>
            </div>
          </article>
        </section>

        <section className="footer-banner">
          <div>
            <span className="pill">Built for creators</span>
            <h2>Premium, simple, and fast.</h2>
            <p>
              This layout is made to feel expensive without looking messy. Dark premium colors, bright accents, clear cards, and short words.
            </p>
          </div>
          <div className="tag-grid">
            {["Hook analyzer", "Title fix", "Thumbnail roast", "Retention score", "Rewrite suggestions", "Shareable report"].map((item) => (
              <span key={item}>{item}</span>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

function FeatureCard({ title, text }) {
  return (
    <div className="glass-card">
      <strong>{title}</strong>
      <p>{text}</p>
    </div>
  );
}

function MiniTile({ title, text }) {
  return (
    <div className="small-card">
      <span>{title}</span>
      <p>{text}</p>
    </div>
  );
}

function MetricCard({ title, value, helper }) {
  return (
    <div className="metric-card">
      <span>{title}</span>
      <strong>{value}</strong>
      <p>{helper}</p>
    </div>
  );
}

function CopyPanel({ title, items, onCopy }) {
  return (
    <article className="panel">
      <div className="panel-head">
        <div>
          <h2>{title}</h2>
        </div>
        <button className="btn btn-ghost" onClick={onCopy}>Copy</button>
      </div>
      <div className="stack">
        {items.map((item) => (
          <div key={item} className="mini-list">{item}</div>
        ))}
      </div>
    </article>
  );
}

function BarChartSimple({ values, labels }) {
  const max = Math.max(...values);
  return (
    <div className="bar-chart">
      {values.map((value, idx) => (
        <div key={labels[idx]} className="bar-col">
          <div className="bar-track">
            <div className="bar-fill" style={{ height: `${Math.max(12, (value / max) * 100)}%` }} />
          </div>
          <span>{labels[idx]}</span>
          <small>{value}</small>
        </div>
      ))}
    </div>
  );
}

export default App;
