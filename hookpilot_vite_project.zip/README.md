# HookPilot Analyzer

A deploy-ready Vite + React project for creator analytics.

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Deploy
Upload the project to GitHub and connect it to Vercel, or deploy with your host of choice.

## Notes
- Login is local-browser only.
- History is saved in localStorage.
- Export supports JSON and CSV.
