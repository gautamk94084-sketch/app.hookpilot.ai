HookPilot Analyzer App

Files:
- src/App.jsx

Notes:
- This is the full frontend component code.
- Login/history is browser localStorage based.
- Uses shadcn/ui style components and lucide-react.
