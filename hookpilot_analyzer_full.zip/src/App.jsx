import React, { useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  BarChart3,
  Bolt,
  CheckCircle2,
  Copy,
  Crown,
  Gauge,
  Sparkles,
  Target,
  TriangleAlert,
  Wand2,
  Zap,
  Download,
  History,
  LogIn,
  LogOut,
  Save,
  UserRound,
  ClipboardCopy,
} from "lucide-react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Bar, BarChart, Cell } from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";

const SAMPLE_PRESETS = [
  {
    label: "Shorts Hook",
    value: "This cat waited outside the hospital for 3 days… then the door finally opened.",
  },
  {
    label: "Title + Hook",
    value: "He ignored this puppy for one week… until the puppy did THIS.",
  },
  {
    label: "Weak Example",
    value: "Today I want to talk about my video and share some thoughts with you.",
  },
];

const curiosityWords = ["wait", "suddenly", "only", "before", "after", "until", "never", "why", "how", "secret", "hidden", "wrong", "finally", "unexpected", "nobody"];
const emotionWords = ["cry", "love", "hurt", "saved", "lost", "fear", "alone", "family", "heart", "pain", "happy", "shock", "relief", "hero"];
const urgencyWords = ["now", "today", "right", "instant", "fast", "quick", "before", "last", "first", "suddenly"];
const stakeWords = ["save", "risk", "lose", "win", "survive", "danger", "chance", "mystery", "secret", "proof", "truth", "attack", "escape"];

const metricData = [
  { name: "Hook", score: 86 },
  { name: "Curiosity", score: 73 },
  { name: "Emotion", score: 81 },
  { name: "Clarity", score: 90 },
  { name: "Retention", score: 78 },
];

const trendData = [
  { day: "Mon", views: 12 },
  { day: "Tue", views: 19 },
  { day: "Wed", views: 16 },
  { day: "Thu", views: 31 },
  { day: "Fri", views: 27 },
  { day: "Sat", views: 41 },
  { day: "Sun", views: 55 },
];

const heatData = [
  { label: "Good", value: 62 },
  { label: "Weak", value: 21 },
  { label: "Needs Fix", value: 17 },
];

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function scoreText(text) {
  const clean = text.trim();
  const words = clean ? clean.split(/\s+/).filter(Boolean) : [];
  const lower = clean.toLowerCase();

  const hasCuriosity = curiosityWords.some((w) => lower.includes(w));
  const hasEmotion = emotionWords.some((w) => lower.includes(w));
  const hasUrgency = urgencyWords.some((w) => lower.includes(w));
  const hasStake = stakeWords.some((w) => lower.includes(w));
  const hasNumber = /\d/.test(clean);
  const hasQuestion = /\?/.test(clean);
  const hasEllipse = /\.\.\.|…/.test(clean);

  let score = 38;
  if (words.length >= 5 && words.length <= 18) score += 10;
  if (words.length > 18) score -= 8;
  if (words.length < 3) score -= 10;
  if (hasCuriosity) score += 12;
  if (hasEmotion) score += 10;
  if (hasUrgency) score += 6;
  if (hasStake) score += 10;
  if (hasNumber) score += 7;
  if (hasQuestion) score += 3;
  if (hasEllipse) score += 4;
  if (/\b(I want to talk|today I|this is about|in this video)\b/i.test(clean)) score -= 14;
  if (/\bhello|hi everyone|welcome back\b/i.test(lower)) score -= 8;

  score = clamp(score, 5, 98);

  const issues = [];
  if (words.length < 5) issues.push("Too short. Add a clear situation.");
  if (words.length > 18) issues.push("Too long. Cut the setup.");
  if (!hasCuriosity) issues.push("No curiosity word. Add tension or surprise.");
  if (!hasEmotion) issues.push("No emotion. Make the viewer feel something.");
  if (!hasStake) issues.push("No stakes. Show what is at risk.");
  if (!hasNumber && !hasQuestion) issues.push("No pattern break. Add a number or question.");
  if (/\bI want to talk|today I|in this video\b/i.test(clean)) issues.push("Sounds generic. Start with the moment, not the explanation.");

  const strengths = [];
  if (hasCuriosity) strengths.push("Curiosity is present.");
  if (hasEmotion) strengths.push("Emotion is present.");
  if (hasStake) strengths.push("There is a real consequence.");
  if (hasNumber) strengths.push("A number makes it easier to stop the scroll.");
  if (hasQuestion) strengths.push("A question creates instant open loop.");
  if (strengths.length === 0) strengths.push("Clear enough to understand fast.");

  const style = score >= 80 ? "Strong" : score >= 60 ? "Okay" : score >= 40 ? "Weak" : "Very weak";

  const rewrites = generateRewrites(clean, score, hasCuriosity, hasEmotion, hasStake, hasNumber);
  const thumbnail = generateThumbnailFix(clean, score);
  const retention = generateRetentionTips(clean, score, hasEmotion, hasStake);

  return {
    score,
    style,
    strengths,
    issues,
    rewrites,
    thumbnail,
    retention,
    summary: makeSummary(score),
  };
}

function makeSummary(score) {
  if (score >= 80) return `Good hook. It is short, clear, and scroll-stopping.`;
  if (score >= 60) return `Decent base. It needs more curiosity or stronger tension.`;
  return `Weak start. It explains too much and does not create a reason to keep watching.`;
}

function generateRewrites(text, score, hasCuriosity, hasEmotion, hasStake, hasNumber) {
  const base = text.replace(/\s+/g, " ").trim();
  const shortBase = base.length > 80 ? base.slice(0, 77).trim() + "…" : base;

  const lines = [];
  if (score >= 80) {
    lines.push(`Keep the core idea. Make the payoff slightly later: “${shortBase}”`);
    lines.push(`Try a sharper version: “You will not believe what happened after this.”`);
    lines.push(`Add one more tension word: “${shortBase}”`);
  } else if (score >= 60) {
    lines.push(hasCuriosity ? `Make it punchier: “${shortBase}”` : `Add curiosity: “Nobody expected this to happen next…”`);
    lines.push(hasEmotion ? `Keep the emotion, but cut filler.` : `Add emotion: “This looked harmless, but it changed everything.”`);
    lines.push(hasStake ? `Push the consequence harder.` : `Show what was about to be lost.`);
  } else {
    lines.push(`“Something was wrong… and nobody noticed it at first.”`);
    lines.push(`“This looked normal, until the last second.”`);
    lines.push(`“One small moment changed the whole video.”`);
  }

  if (hasNumber || score < 70) lines.push(`“${shortBase.split(" ").slice(0, 10).join(" ")}”`);

  return lines.slice(0, 4);
}

function generateThumbnailFix(text, score) {
  const lower = text.toLowerCase();
  const hasFace = /cat|dog|child|man|woman|boy|girl|owner|baby|animal/.test(lower);
  const hasTextPrompt = /why|how|wait|suddenly|secret|shock|danger|save/.test(lower);
  const notes = [];

  if (score >= 80) {
    notes.push("Thumbnail can stay simple.");
    notes.push("Use 2 to 4 words only.");
    notes.push("Show one clear emotion.");
  } else {
    notes.push("Use one face or one main subject.");
    notes.push("Keep text short and bold.");
    notes.push("Make the result obvious in one glance.");
  }

  if (!hasFace) notes.push("Add a human or animal emotion point.");
  if (!hasTextPrompt) notes.push("Try text like: 'What happened?', 'Too late', 'Wait for it'.");

  return notes.slice(0, 4);
}

function generateRetentionTips(text, score, hasEmotion, hasStake) {
  const tips = [];
  if (score >= 80) {
    tips.push("Keep the first line fast.");
    tips.push("Show the payoff just a little later.");
    tips.push("Use one strong visual every 2–3 seconds.");
  } else {
    tips.push("Cut the intro.");
    tips.push("Start from the problem, not the explanation.");
    tips.push("Add tension before the full story.");
  }
  if (!hasEmotion) tips.push("Add a feeling: fear, love, shock, relief, or loss.");
  if (!hasStake) tips.push("Show what can be lost or gained.");
  return tips.slice(0, 4);
}

const STORAGE_KEYS = {
  user: "hookpilot_user_v1",
  history: "hookpilot_history_v1",
};

function App() {
  const [input, setInput] = useState(SAMPLE_PRESETS[0].value);
  const [copied, setCopied] = useState(false);
  const [userName, setUserName] = useState("");
  const [loginInput, setLoginInput] = useState("");
  const [history, setHistory] = useState([]);
  const [historyCopied, setHistoryCopied] = useState(false);
  const analysis = useMemo(() => scoreText(input), [input]);

  useEffect(() => {
    try {
      const savedUser = localStorage.getItem(STORAGE_KEYS.user);
      const savedHistory = localStorage.getItem(STORAGE_KEYS.history);
      if (savedUser) setUserName(savedUser);
      if (savedHistory) setHistory(JSON.parse(savedHistory));
    } catch {
      // ignore storage errors
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.history, JSON.stringify(history));
    } catch {
      // ignore storage errors
    }
  }, [history]);

  const progressColor =
    analysis.score >= 80
      ? "from-emerald-400 to-cyan-400"
      : analysis.score >= 60
        ? "from-cyan-400 to-blue-400"
        : analysis.score >= 40
          ? "from-amber-400 to-orange-400"
          : "from-rose-400 to-red-500";

  const isLoggedIn = Boolean(userName);

  const handleCopy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      setCopied(false);
    }
  };

  const analysisBundle = useMemo(() => {
    return [
      `Hook score: ${analysis.score}/100`,
      `Style: ${analysis.style}`,
      `Summary: ${analysis.summary}`,
      `Strengths:\n- ${analysis.strengths.join("\n- ")}`,
      `Issues:\n- ${analysis.issues.length ? analysis.issues.join("\n- ") : "No major issue found."}`,
      `Better rewrites:\n- ${analysis.rewrites.join("\n- ")}`,
      `Thumbnail fixes:\n- ${analysis.thumbnail.join("\n- ")}`,
      `Retention tips:\n- ${analysis.retention.join("\n- ")}`,
    ].join("\n\n");
  }, [analysis]);

  const saveCurrent = () => {
    if (!isLoggedIn) return;
    const entry = {
      id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
      userName,
      input,
      score: analysis.score,
      style: analysis.style,
      summary: analysis.summary,
      createdAt: new Date().toISOString(),
      strengths: analysis.strengths,
      issues: analysis.issues,
      rewrites: analysis.rewrites,
      thumbnail: analysis.thumbnail,
      retention: analysis.retention,
    };
    setHistory((prev) => [entry, ...prev].slice(0, 50));
  };

  const login = () => {
    const cleaned = loginInput.trim();
    if (!cleaned) return;
    setUserName(cleaned);
    setLoginInput("");
    try {
      localStorage.setItem(STORAGE_KEYS.user, cleaned);
    } catch {
      // ignore
    }
  };

  const logout = () => {
    setUserName("");
    setHistory([]);
    try {
      localStorage.removeItem(STORAGE_KEYS.user);
      localStorage.removeItem(STORAGE_KEYS.history);
    } catch {
      // ignore
    }
  };

  const exportHistory = (format = "json") => {
    const safeHistory = history.map((item) => ({
      userName: item.userName,
      input: item.input,
      score: item.score,
      style: item.style,
      summary: item.summary,
      createdAt: item.createdAt,
    }));

    let content = "";
    let mime = "text/plain";
    let filename = `hookpilot-history.${format}`;

    if (format === "csv") {
      mime = "text/csv";
      filename = "hookpilot-history.csv";
      const header = ["createdAt", "score", "style", "summary", "input"];
      const rows = safeHistory.map((row) =>
        [row.createdAt, row.score, row.style, row.summary, row.input]
          .map((v) => `"${String(v ?? "").replaceAll('"', '""')}"`)
          .join(",")
      );
      content = [header.join(","), ...rows].join("\n");
    } else {
      content = JSON.stringify(safeHistory, null, 2);
      filename = "hookpilot-history.json";
      mime = "application/json";
    }

    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const copyHistoryText = async () => {
    const text = history
      .map((item, idx) => `${idx + 1}. ${item.score}/100 — ${item.summary}\n${item.input}`)
      .join("\n\n");
    await handleCopy(text || "No saved history yet.");
    setHistoryCopied(true);
    setTimeout(() => setHistoryCopied(false), 1500);
  };

  return (
    <div className="min-h-screen bg-[#07111f] text-slate-100">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(45,212,191,0.16),transparent_28%),radial-gradient(circle_at_top_right,rgba(99,102,241,0.18),transparent_30%),radial-gradient(circle_at_bottom,rgba(168,85,247,0.15),transparent_32%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(to_bottom,rgba(255,255,255,0.04),transparent_12%,transparent_88%,rgba(255,255,255,0.02))]" />

        <main className="relative mx-auto max-w-7xl px-4 py-8 md:px-8 lg:py-10">
          <section className="mb-8 grid gap-6 lg:grid-cols-[1.3fr_0.9fr] lg:items-center">
            <div className="space-y-5">
              <Badge className="w-fit border border-cyan-400/30 bg-cyan-400/10 px-3 py-1 text-cyan-200 hover:bg-cyan-400/10">
                <Crown className="mr-2 h-4 w-4" /> Premium creator analytics
              </Badge>
              <div className="space-y-3">
                <h1 className="max-w-3xl text-4xl font-black tracking-tight text-white md:text-6xl">
                  Why Your Video Won&apos;t Go Viral
                  <span className="block bg-gradient-to-r from-cyan-300 via-blue-300 to-violet-300 bg-clip-text text-transparent">
                    Analyzer
                  </span>
                </h1>
                <p className="max-w-2xl text-base leading-7 text-slate-300 md:text-lg">
                  Paste your hook, title, or script. Get a fast score, weak points, better rewrites, thumbnail fixes, and retention tips in simple words.
                </p>
              </div>

              <div className="flex flex-wrap gap-3">
                <Button className="rounded-2xl bg-white px-5 py-6 text-slate-950 shadow-lg shadow-cyan-500/10 hover:bg-slate-100">
                  <Zap className="mr-2 h-4 w-4" /> Analyze now
                </Button>
                <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5 px-5 py-6 text-white hover:bg-white/10">
                  <ArrowRight className="mr-2 h-4 w-4" /> See how it works
                </Button>
              </div>

              <div className="grid gap-3 sm:grid-cols-3">
                {[
                  ["Fast score", "Instant hook score from 1–100"],
                  ["Simple words", "No confusing jargon, just clear fixes"],
                  ["Creator focused", "Built for Shorts, Reels, and YouTube"],
                ].map(([title, desc]) => (
                  <Card key={title} className="border-white/10 bg-white/5 backdrop-blur-xl">
                    <CardContent className="p-4">
                      <div className="text-sm font-semibold text-white">{title}</div>
                      <div className="mt-1 text-sm text-slate-300">{desc}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <Card className="border-cyan-400/20 bg-[#0b1b30]/90 shadow-2xl shadow-black/30 backdrop-blur-xl">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-white">
                  <Sparkles className="h-5 w-5 text-cyan-300" /> Live result preview
                </CardTitle>
                <CardDescription className="text-slate-400">This shows the style of the app output.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-white/5 to-white/[0.02] p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-slate-400">Hook score</div>
                      <div className="text-3xl font-black text-white">{analysis.score}/100</div>
                    </div>
                    <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
                      <Gauge className="h-6 w-6 text-cyan-300" />
                    </div>
                  </div>
                  <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10">
                    <div className={`h-full rounded-full bg-gradient-to-r ${progressColor}`} style={{ width: `${analysis.score}%` }} />
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2 text-xs text-slate-300">
                    <Badge variant="secondary" className="bg-white/10 text-slate-200 hover:bg-white/10">{analysis.style}</Badge>
                    <Badge variant="secondary" className="bg-white/10 text-slate-200 hover:bg-white/10">Retention check</Badge>
                    <Badge variant="secondary" className="bg-white/10 text-slate-200 hover:bg-white/10">Thumbnail ideas</Badge>
                  </div>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <Card className="border-white/10 bg-white/5">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 text-sm text-slate-300"><Target className="h-4 w-4 text-cyan-300" /> Best part</div>
                      <p className="mt-2 text-sm text-white">{analysis.strengths[0]}</p>
                    </CardContent>
                  </Card>
                  <Card className="border-white/10 bg-white/5">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 text-sm text-slate-300"><TriangleAlert className="h-4 w-4 text-amber-300" /> Biggest issue</div>
                      <p className="mt-2 text-sm text-white">{analysis.issues[0] || "Looks okay at first glance."}</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </section>

          <section className="mb-6 grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
            <Card className="border-white/10 bg-white/6 shadow-2xl shadow-black/20 backdrop-blur-xl">
              <CardHeader>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-white">
                      <Wand2 className="h-5 w-5 text-cyan-300" /> Paste your text
                    </CardTitle>
                    <CardDescription className="text-slate-400">Hook, title, intro, or full short script.</CardDescription>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {SAMPLE_PRESETS.map((preset) => (
                      <Button
                        key={preset.label}
                        variant="outline"
                        className="rounded-full border-white/10 bg-white/5 text-xs text-slate-100 hover:bg-white/10"
                        onClick={() => setInput(preset.value)}
                      >
                        {preset.label}
                      </Button>
                    ))}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Paste your hook or script here..."
                  className="min-h-40 rounded-2xl border-white/10 bg-[#081224] text-base text-white placeholder:text-slate-500 focus-visible:ring-cyan-400"
                />
                <div className="flex flex-wrap items-center gap-3">
                  <Button className="rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 px-5 py-6 text-white shadow-lg shadow-cyan-500/20 hover:opacity-95">
                    <Bolt className="mr-2 h-4 w-4" /> Analyze instantly
                  </Button>
                  <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5 px-5 py-6 text-white hover:bg-white/10" onClick={() => handleCopy(input)}>
                    <Copy className="mr-2 h-4 w-4" /> {copied ? "Copied" : "Copy input"}
                  </Button>
                  <div className="text-sm text-slate-400">Short, sharp, and honest.</div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-white/10 bg-white/6 shadow-2xl shadow-black/20 backdrop-blur-xl">
              <CardHeader>
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-white">
                      <UserRound className="h-5 w-5 text-cyan-300" /> Login
                    </CardTitle>
                    <CardDescription className="text-slate-400">Local login for saving history in this browser.</CardDescription>
                  </div>
                  <Badge className={`${isLoggedIn ? "bg-emerald-500/15 text-emerald-200" : "bg-white/10 text-slate-200"} border border-white/10`}>
                    {isLoggedIn ? "Signed in" : "Guest"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {!isLoggedIn ? (
                  <>
                    <Input
                      value={loginInput}
                      onChange={(e) => setLoginInput(e.target.value)}
                      placeholder="Enter your name or email"
                      className="h-12 rounded-2xl border-white/10 bg-[#081224] text-white placeholder:text-slate-500 focus-visible:ring-cyan-400"
                    />
                    <Button className="w-full rounded-2xl bg-white px-5 py-6 text-slate-950 hover:bg-slate-100" onClick={login}>
                      <LogIn className="mr-2 h-4 w-4" /> Login and save history
                    </Button>
                    <div className="text-sm text-slate-400">Without login, nothing is stored. With login, your history stays in this browser.</div>
                  </>
                ) : (
                  <div className="space-y-3">
                    <div className="rounded-2xl border border-white/10 bg-black/20 p-4 text-sm text-slate-200">
                      Logged in as <span className="font-semibold text-white">{userName}</span>
                    </div>
                    <div className="grid gap-2 sm:grid-cols-2">
                      <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5 text-white hover:bg-white/10" onClick={saveCurrent}>
                        <Save className="mr-2 h-4 w-4" /> Save current result
                      </Button>
                      <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5 text-white hover:bg-white/10" onClick={logout}>
                        <LogOut className="mr-2 h-4 w-4" /> Logout
                      </Button>
                    </div>
                    <div className="grid gap-2 sm:grid-cols-2">
                      <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5 text-white hover:bg-white/10" onClick={() => exportHistory("json")}>
                        <Download className="mr-2 h-4 w-4" /> Export JSON
                      </Button>
                      <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5 text-white hover:bg-white/10" onClick={() => exportHistory("csv")}>
                        <Download className="mr-2 h-4 w-4" /> Export CSV
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </section>

          <section className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
            <Card className="border-white/10 bg-white/6 shadow-2xl shadow-black/20 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <BarChart3 className="h-5 w-5 text-cyan-300" /> Fast analytics
                </CardTitle>
                <CardDescription className="text-slate-400">This is the dashboard feel for your premium version.</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="score" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 rounded-2xl bg-white/5 p-1">
                    <TabsTrigger value="score" className="rounded-xl data-[state=active]:bg-white data-[state=active]:text-slate-950">Score</TabsTrigger>
                    <TabsTrigger value="trend" className="rounded-xl data-[state=active]:bg-white data-[state=active]:text-slate-950">Trend</TabsTrigger>
                    <TabsTrigger value="mix" className="rounded-xl data-[state=active]:bg-white data-[state=active]:text-slate-950">Mix</TabsTrigger>
                  </TabsList>

                  <TabsContent value="score" className="mt-4 space-y-4">
                    <div className="grid gap-3 sm:grid-cols-2">
                      <MetricCard title="Hook score" value={`${analysis.score}/100`} helper="How strong the first line is" accent="from-cyan-400 to-blue-500" />
                      <MetricCard title="Swipe risk" value={analysis.score >= 80 ? "Low" : analysis.score >= 60 ? "Medium" : "High"} helper="Chance people skip" accent="from-violet-400 to-fuchsia-500" />
                      <MetricCard title="Clarity" value={analysis.score >= 75 ? "Strong" : "Okay"} helper="Simple to understand fast" accent="from-emerald-400 to-cyan-500" />
                      <MetricCard title="Emotion" value={analysis.score >= 70 ? "Good" : "Needs work"} helper="Feeling, shock, or tension" accent="from-amber-400 to-orange-500" />
                    </div>
                    <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
                      <div className="mb-3 flex items-center justify-between text-sm text-slate-300">
                        <span>Performance snapshot</span>
                        <span>{analysis.summary}</span>
                      </div>
                      <ResponsiveContainer width="100%" height={220}>
                        <BarChart data={metricData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.07)" />
                          <XAxis dataKey="name" stroke="rgba(226,232,240,0.6)" />
                          <YAxis stroke="rgba(226,232,240,0.6)" />
                          <Tooltip contentStyle={{ background: "#091527", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 16, color: "#fff" }} />
                          <Bar dataKey="score" radius={[10, 10, 0, 0]}>
                            {metricData.map((entry, idx) => (
                              <Cell key={`cell-${idx}`} fill={idx % 2 === 0 ? "#22d3ee" : "#8b5cf6"} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </TabsContent>

                  <TabsContent value="trend" className="mt-4 space-y-4">
                    <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
                      <div className="mb-3 flex items-center justify-between text-sm text-slate-300">
                        <span>Daily activity</span>
                        <span>More clicks when hooks improve</span>
                      </div>
                      <ResponsiveContainer width="100%" height={240}>
                        <AreaChart data={trendData}>
                          <defs>
                            <linearGradient id="viewsGrad" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.45} />
                              <stop offset="95%" stopColor="#22d3ee" stopOpacity={0.02} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.07)" />
                          <XAxis dataKey="day" stroke="rgba(226,232,240,0.6)" />
                          <YAxis stroke="rgba(226,232,240,0.6)" />
                          <Tooltip contentStyle={{ background: "#091527", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 16, color: "#fff" }} />
                          <Area type="monotone" dataKey="views" stroke="#22d3ee" fillOpacity={1} fill="url(#viewsGrad)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </TabsContent>

                  <TabsContent value="mix" className="mt-4 space-y-4">
                    <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
                      <div className="mb-3 flex items-center justify-between text-sm text-slate-300">
                        <span>Content health mix</span>
                        <span>Quick read for fast decisions</span>
                      </div>
                      <div className="space-y-4">
                        {heatData.map((item) => (
                          <div key={item.label}>
                            <div className="mb-2 flex items-center justify-between text-sm text-slate-300">
                              <span>{item.label}</span>
                              <span>{item.value}%</span>
                            </div>
                            <Progress value={item.value} className="h-3 bg-white/10" />
                          </div>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            <Card className="border-white/10 bg-white/6 shadow-2xl shadow-black/20 backdrop-blur-xl">
              <CardHeader>
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-white">
                      <History className="h-5 w-5 text-cyan-300" /> Saved history
                    </CardTitle>
                    <CardDescription className="text-slate-400">Your last saved checks.</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="rounded-xl border-white/10 bg-white/5 text-white hover:bg-white/10" onClick={copyHistoryText}>
                      <ClipboardCopy className="mr-2 h-4 w-4" /> {historyCopied ? "Copied" : "Copy all"}
                    </Button>
                    <Button variant="outline" size="sm" className="rounded-xl border-white/10 bg-white/5 text-white hover:bg-white/10" onClick={() => exportHistory("json")}>
                      <Download className="mr-2 h-4 w-4" /> Export
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {isLoggedIn ? (
                  history.length ? (
                    history.slice(0, 5).map((item) => (
                      <div key={item.id} className="rounded-2xl border border-white/10 bg-black/20 p-4">
                        <div className="flex items-center justify-between gap-3">
                          <div className="text-sm font-semibold text-white">{item.score}/100 • {item.style}</div>
                          <div className="text-xs text-slate-400">{new Date(item.createdAt).toLocaleString()}</div>
                        </div>
                        <div className="mt-2 text-sm text-slate-300">{item.summary}</div>
                        <div className="mt-3 rounded-xl border border-white/10 bg-white/5 p-3 text-sm text-slate-200 line-clamp-4">
                          {item.input}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="rounded-2xl border border-dashed border-white/10 bg-black/20 p-6 text-sm text-slate-400">
                      No saved history yet. Login, then click “Save current result”.
                    </div>
                  )
                ) : (
                  <div className="rounded-2xl border border-dashed border-white/10 bg-black/20 p-6 text-sm text-slate-400">
                    Login first to save and export history.
                  </div>
                )}
              </CardContent>
            </Card>
          </section>

          <section className="mt-6 grid gap-6 lg:grid-cols-3">
            <CopyPanel title="What works" icon={<CheckCircle2 className="h-5 w-5 text-emerald-300" />} items={analysis.strengths} onCopy={() => handleCopy(analysis.strengths.join("\n"))} />
            <CopyPanel title="What fails" icon={<TriangleAlert className="h-5 w-5 text-amber-300" />} items={analysis.issues.length ? analysis.issues : ["No major issue found."]} onCopy={() => handleCopy(analysis.issues.join("\n"))} />
            <CopyPanel title="Premium outputs" icon={<Crown className="h-5 w-5 text-cyan-300" />} items={["4 better hook rewrites", "Thumbnail text ideas", "Retention fix tips", "Shareable report card"]} onCopy={() => handleCopy(analysisBundle)} />
          </section>

          <section className="mt-6 grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
            <Card className="border-white/10 bg-[#0b1b30]/90 backdrop-blur-xl">
              <CardHeader>
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <CardTitle className="text-white">Better rewrites</CardTitle>
                    <CardDescription className="text-slate-400">These are written to stop the scroll.</CardDescription>
                  </div>
                  <Button variant="outline" size="sm" className="rounded-xl border-white/10 bg-white/5 text-white hover:bg-white/10" onClick={() => handleCopy(analysis.rewrites.join("\n"))}>
                    <ClipboardCopy className="mr-2 h-4 w-4" /> Copy rewrites
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {analysis.rewrites.map((item, idx) => (
                  <div key={item} className="flex gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/10 text-sm font-bold text-white">{idx + 1}</div>
                    <div className="text-sm leading-6 text-slate-200">{item}</div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border-white/10 bg-[#0b1b30]/90 backdrop-blur-xl">
              <CardHeader>
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <CardTitle className="text-white">Thumbnail and retention fixes</CardTitle>
                    <CardDescription className="text-slate-400">Simple fixes you can actually use.</CardDescription>
                  </div>
                  <Button variant="outline" size="sm" className="rounded-xl border-white/10 bg-white/5 text-white hover:bg-white/10" onClick={() => handleCopy([...analysis.thumbnail, ...analysis.retention].join("\n"))}>
                    <ClipboardCopy className="mr-2 h-4 w-4" /> Copy fixes
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="grid gap-4 md:grid-cols-2">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                  <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                    <Wand2 className="h-4 w-4 text-cyan-300" /> Thumbnail
                  </div>
                  <div className="space-y-2 text-sm text-slate-300">
                    {analysis.thumbnail.map((item) => (
                      <div key={item} className="rounded-xl border border-white/10 bg-black/10 p-3">{item}</div>
                    ))}
                  </div>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                  <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                    <Gauge className="h-4 w-4 text-cyan-300" /> Retention
                  </div>
                  <div className="space-y-2 text-sm text-slate-300">
                    {analysis.retention.map((item) => (
                      <div key={item} className="rounded-xl border border-white/10 bg-black/10 p-3">{item}</div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>

          <section className="mt-8">
            <Card className="overflow-hidden border-cyan-400/20 bg-gradient-to-r from-[#0e1f35] via-[#091527] to-[#101a34] shadow-2xl shadow-black/30">
              <CardContent className="grid gap-6 p-6 md:grid-cols-[1.1fr_0.9fr] md:p-8">
                <div className="space-y-3">
                  <Badge className="border border-white/10 bg-white/10 px-3 py-1 text-white hover:bg-white/10">Built for creators</Badge>
                  <h2 className="text-2xl font-black text-white md:text-4xl">Premium, simple, and fast.</h2>
                  <p className="max-w-2xl text-slate-300">
                    This layout is made to feel expensive without looking messy. Dark premium colors, bright accents, clear cards, and short words.
                  </p>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  {[
                    "Hook analyzer",
                    "Title fix",
                    "Thumbnail roast",
                    "Retention score",
                    "Rewrite suggestions",
                    "Shareable report",
                  ].map((item) => (
                    <div key={item} className="rounded-2xl border border-white/10 bg-white/5 p-3 text-sm text-slate-200">
                      {item}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </section>
        </main>
      </div>
    </div>
  );
}

function MetricCard({ title, value, helper, accent }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4 shadow-lg shadow-black/10">
      <div className="text-sm text-slate-400">{title}</div>
      <div className="mt-2 text-2xl font-black text-white">{value}</div>
      <div className="mt-2 text-sm text-slate-300">{helper}</div>
      <div className={`mt-4 h-1.5 rounded-full bg-gradient-to-r ${accent}`} />
    </div>
  );
}

function CopyPanel({ title, icon, items, onCopy }) {
  return (
    <Card className="border-white/10 bg-white/5 backdrop-blur-xl">
      <CardHeader>
        <div className="flex items-center justify-between gap-3">
          <CardTitle className="flex items-center gap-2 text-white">
            {icon} {title}
          </CardTitle>
          <Button variant="outline" size="sm" className="rounded-xl border-white/10 bg-white/5 text-white hover:bg-white/10" onClick={onCopy}>
            <ClipboardCopy className="mr-2 h-4 w-4" /> Copy
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-2 text-sm text-slate-300">
        {items.map((item) => (
          <div key={item} className="rounded-xl border border-white/10 bg-black/10 p-3">
            {item}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

export default App;
